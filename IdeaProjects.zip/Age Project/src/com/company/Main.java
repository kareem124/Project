package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {


        Scanner myObj = new Scanner(System.in);
        System.out.println("Please Enter Your Age");

        int age = myObj.nextInt();
        if(age<21){
            System.out.println("You Are Not Be Able To Continue");

        }else {
            System.out.println("Welcome");
        }

    }
}
