package com.company;

import java.util.Scanner;

public class Main {


    public static void main(String[] args) {
        Scanner o = new Scanner(System.in);
        System.out.println("Enter Email");

        String Email = o.nextLine();
        System.out.println("Email is: " + Email);





        Scanner ka = new Scanner(System.in);
        System.out.println("Enter Password");

        String Password = ka.nextLine();
        System.out.println("Password is: " + Password);














    }


}
