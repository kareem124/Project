package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int num1 , num2;

        Scanner even = new Scanner(System.in);

        System.out.println("Please Write Even Number");
        num1 = even.nextInt();
        System.out.println("Please Write Another Number");

        num2 = even.nextInt();
      int i = 10;
if (num1 < 9){
    System.out.println("Even Number");

}

else  {
            System.out.println("Odd Number");
        }




    }
}
