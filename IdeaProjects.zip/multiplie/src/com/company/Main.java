package com.company;

public class Main {

    public static void main(String[] args) {
	int num1 = 9;
            int num2 = 4;
            int num3 = 7;
            int result = num1 - num3 - num2 +14;
        System.out.println(result);

    }
}
